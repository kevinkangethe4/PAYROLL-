﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration; 


namespace payroll
{
    public partial class prform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // if (!string.IsNullOrEmpty(TextBox7.Text) && !string.IsNullOrEmpty(TextBox8.Text) && !string.IsNullOrEmpty(TextBox9.Text) && !string.IsNullOrEmpty(TextBox10.Text) && !string.IsNullOrEmpty(TextBox11.Text) && !string.IsNullOrEmpty(TextBox12.Text))
              //  TextBox12.Text = (Convert.ToInt32(TextBox7.Text) + Convert.ToInt32(TextBox8.Text) + Convert.ToInt32(TextBox9.Text) + Convert.ToInt32(TextBox10.Text) + Convert.ToInt32(TextBox11.Text)).ToString();
            //int a = Convert.ToInt32(TextBox7.Text);
           // int b = Convert.ToInt32(TextBox8.Text);
            //int c = Convert.ToInt32(TextBox9.Text);
           // int d = Convert.ToInt32(TextBox10.Text);
           // int t = Convert.ToInt32(TextBox11.Text);
            //TextBox12.Text = a + b + c + d + t.ToString();
   
  int v2 = 0;
  int v3 = 0;
  int v4 = 0;
  int v5 = 0;

  int result = 0;


  if ( int.TryParse(TextBox8.Text, out v2)& int.TryParse(TextBox9.Text, out v3)& int.TryParse(TextBox10.Text, out v4)& int.TryParse(TextBox11.Text, out v5))
  {
      result =  v2 + v3 + v4 + v5;
      TextBox12.Text = result.ToString();
  }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int v2 = 0;
            int v3 = 0;
            int v4 = 0;
           

            int result = 0;


            if (int.TryParse(TextBox13.Text, out v2) & int.TryParse(TextBox14.Text, out v3) & int.TryParse(TextBox15.Text, out v4))
            {
                result = v2 + v3 + v4; 
                TextBox16.Text = result.ToString();
            }

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(TextBox7.Text);

            int b = Convert.ToInt32(TextBox12.Text);

            int c = a - b;

            TextBox18.Text = Convert.ToString(c);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int v2 = 0;
            int v3 = 0;
            


            int result = 0;


            if (int.TryParse(TextBox18.Text, out v2) & int.TryParse(TextBox16.Text, out v3))
            {
                result = v2 + v3 ;
                TextBox17.Text = result.ToString();
            }

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Database1ConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into tblpayroll(emlno,payrno,fname,lname,jgroup,gender,basic,nssf,nhif,paye,td,tb,hou,com,others,ta,np)values (@emlno,@payrno,@fname,@lname,@jgroup,@gender,@basic,@nssf,@nhif,@paye,@td,@tb,@hou,@com,@others,@ta,@np)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@emlno", TextBox5.Text);
                cmd.Parameters.AddWithValue("@payrno", TextBox1.Text);
                cmd.Parameters.AddWithValue("@fname", TextBox3.Text);
                cmd.Parameters.AddWithValue("@lname", TextBox4.Text);
                cmd.Parameters.AddWithValue("@jgroup", TextBox6.Text);
                cmd.Parameters.AddWithValue("@gender", ddl.Text);
                cmd.Parameters.AddWithValue("@basic", TextBox7.Text);
                cmd.Parameters.AddWithValue("@nssf", TextBox8.Text);
                cmd.Parameters.AddWithValue("@nhif", TextBox9.Text);
                cmd.Parameters.AddWithValue("@paye", TextBox10.Text);
                cmd.Parameters.AddWithValue("@td", TextBox12.Text);
                cmd.Parameters.AddWithValue("@tb", TextBox18.Text);
                cmd.Parameters.AddWithValue("@hou", TextBox13.Text);
                cmd.Parameters.AddWithValue("@com", TextBox14.Text);
                cmd.Parameters.AddWithValue("@others", TextBox15.Text);
                cmd.Parameters.AddWithValue("@ta", TextBox16.Text);
                cmd.Parameters.AddWithValue("@np", TextBox17.Text);
                cmd.ExecuteNonQuery();
               
                Response.Write("registeration Successfully!!!thank you");

                conn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("error" + ex.ToString());
            }  

        }
    }
}