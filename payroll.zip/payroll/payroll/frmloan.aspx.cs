﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace payroll
{
    public partial class frmloan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Database1ConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into tblloan(empno,date,fname,lname,lg,md)values (@empno,@date,@fname,@lname,@lg,@md)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@empno", TextBox1.Text);
                cmd.Parameters.AddWithValue("@date", TextBox2.Text);
                cmd.Parameters.AddWithValue("@fname", TextBox3.Text);
                cmd.Parameters.AddWithValue("@lname", TextBox4.Text);
                cmd.Parameters.AddWithValue("@lg", TextBox5.Text);
                cmd.Parameters.AddWithValue("@md", TextBox6.Text);

                cmd.ExecuteNonQuery();

                Response.Write("registeration Successfully!!!thank you");

                conn.Close();

            }
            catch (Exception ex)
            {
                Response.Write("error" + ex.ToString());
            }
        }
    }
}